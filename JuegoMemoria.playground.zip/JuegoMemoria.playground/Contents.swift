import UIKit

var rango =  0...100

for r in rango{
    if r == 0 {
        print("No hay instrucción para el 0")
    }
    if r % 5 == 0 && r % 2 == 0 && r >= 30 && r <= 40{
        print("\(r) es un número par, Bingo y Viva Swift")
    } else if r % 5 == 0 && r % 2 != 0 && r >= 30 && r <= 40{
        print ("\(r) es un número impar,Bingo y Viva Swift")
    } else if r % 5 == 0 && r % 2 == 0 {
        print("\(r) es un número par y Bingo")
    } else if r % 5 == 0 && r % 2 != 0 {
        print ("\(r) es un número impar y Bingo")
    } else if r % 2 == 0 && r >= 30 && r <= 40{
        print("El número \(r) es par y Viva Swift")
    } else if r % 2 != 0 && r >= 30 && r <= 40{
        print("El número \(r) es impar y Viva Swift")
    } else if r % 2 == 0 {
        print("El número \(r) es par")
    } else if r % 2 != 0 {
        print("El número \(r) es impar")
    }
}

